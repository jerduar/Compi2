#ifndef ARBOLJ_H
#define ARBOLJ_H
#include <nodo.h>


class ArbolJ
{
public:
    ArbolJ();
    Nodo *raiz;
    void Recorrer(Nodo *raiz);
    void Dibujar();


};

#endif // ARBOLJ_H
